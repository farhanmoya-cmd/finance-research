---
name: stock-valuation
description: "Use the supplied Stock-Valuation Python DCF project to estimate intrinsic value, WACC, margin of safety or reverse-implied revenue growth for a listed company."
---

# Stock valuation

Read [upstream usage and model formulas](references/upstream.md). The supplied project is in `assets/project/`; inspect `DCFModel.py` before running or adapting it.

1. Establish ticker, exchange, valuation date, reporting currency, share class and fiscal period. For Indonesian stocks, verify the provider's ticker mapping; never silently substitute a US listing.
2. Check Python and the dependencies recorded in `assets/project/requirements.txt`. Use an isolated working copy and environment. These are historical pins, not a claim of compatibility with today's provider APIs.
3. Reconcile downloaded financial line items with company disclosures. Inspect missing data, CapEx signs, working-capital changes, debt, cash, minority interests and diluted shares before trusting the equity bridge.
4. From a working copy of the project, the documented command is:
   `python DCFModel.py --ticker KO --TGR 0.03 --riskfree "^TNX" --market VTI`
   Read the code for supported flags rather than inventing parameters.
5. Review five-year forecasts, tax rate, mid-year cash-flow discounting and year-five terminal discounting. Require WACC greater than terminal growth. Explain the treatment of terminal value, debt-free firms, negative earnings and unusable provider fields.
6. For an investment conclusion, add bear/base/bull assumptions and WACC/growth sensitivity in an explicit calculation. Separate an unmodified upstream output from a revised model.
7. Report the value per share, price date, upside/downside convention, assumptions, EV-to-equity bridge, terminal contribution and data limitations. Do not label archived CSV multiples or README example prices as current.

Verify current data and technical documentation when execution needs a live provider. If the runtime or data is absent, provide an auditable model plan and state that calculations have not run.

