---
name: systemic-risk
description: "Use the supplied MATLAB SystemicRisk framework to prepare financial-sector datasets and analyze interconnectedness, CoVaR, MES, SRISK, liquidity, bubbles or spillovers."
---

# Systemic risk

Read [framework measures, runtime requirements and data schema](references/upstream.md). Code is in `assets/project/`: `run.m`, `analyze.m`, `initialize.m` and the `ScriptsData`, `ScriptsDataset`, `ScriptsModels`, `ScriptsMeasures` and supporting directories.

1. Define the institutions, benchmark, date range, currency and desired measures. Choose a subset appropriate to the data rather than attempting all measures.
2. Inspect `initialize.m`, `run.m` and `ScriptsDataset/parse_dataset.m` for paths and settings. MATLAB and the documented toolboxes must be available; installation of this skill does not supply a MATLAB license.
3. Prepare the workbook schema documented upstream. The minimum is a Shares sheet with dates, benchmark, at least three firms and 253 daily prices or 252 log returns. Never feed raw prices into an input that expects log prices or returns.
4. Match additional inputs to the requested measure: market capitalizations and balance-sheet components for cross-sectional methods; CDS and risk-free rate for relevant default/cross-entropy methods; trading volumes and capitalization for liquidity methods. Preserve units, dates and column ordering.
5. Diagnose missing observations, outliers and illiquidity. Do not mechanically remove distress observations or interpolate crises: record any treatment and assess its effect on tail estimates.
6. Run from a working copy after configuring paths and required output folders. Use `run.m` for computation and `analyze.m` for existing results. Original sample workbooks and MAT caches are omitted from this skill; obtain the required dataset explicitly.
7. Inspect window lengths, convergence, return conventions and defaults/insolvencies. Report units and the exact definition of each metric; distinguish systemic importance, vulnerability, capital shortfall and connectedness.

Cite the method references contained in the upstream overview when explaining individual estimators. Verify primary sources before making precise methodological claims. Do not say the framework ran when only its source was inspected.

