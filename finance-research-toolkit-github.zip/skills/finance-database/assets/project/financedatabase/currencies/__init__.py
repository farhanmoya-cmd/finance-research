"""Currencies Module"""
