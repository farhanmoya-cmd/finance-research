"""Equities Module"""
