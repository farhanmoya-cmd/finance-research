"""Moneymarkets Module"""
