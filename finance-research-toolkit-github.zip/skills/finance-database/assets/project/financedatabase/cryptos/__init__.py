"""Cryptos Module"""
