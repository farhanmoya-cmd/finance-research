---
name: finance-database
description: "Use FinanceDatabase to find and filter financial instrument symbols, identify exchanges and primary listings, or assemble peer and investment universes."
---

# FinanceDatabase

Read [the supplied database documentation](references/upstream.md). Bundled Python source and `pyproject.toml` are in `assets/project/`. The uploaded snapshot declares version 2.5.1 and Python >=3.11,<3.16; check the current runtime and compatible dependencies before execution.

Use instrument metadata to discover a universe. It is not a live price feed, audited financial statement source, or automatic investment recommendation. Large database snapshots are omitted; normal loading may need network access and provider caches.

For equities, the upstream API documents:

```python
import financedatabase as fd
equities = fd.Equities()
results = equities.select(country="Indonesia", only_primary_listing=True)
```

Validate available country/sector/industry/exchange values against the loaded database before filtering. Inspect `financedatabase/equities/equities_controller.py` and `database_controller.py` for actual signatures. Use documented `search` when names or symbols need fuzzy text matching; check ambiguous companies manually.

- Clarify geography, listing market, instrument type, sector and peer-selection criteria.
- Distinguish issuer domicile from trading venue, listing currency and economic exposure.
- Deduplicate share classes/ADRs/cross-listings according to the user's objective; retain excluded listings and the reason when it matters.
- Return symbol, company, exchange/market, currency, country, sector/industry and retrieval date where available.
- Confirm critical ticker/exchange mappings with current exchange or issuer information before financial modeling.
- Record database vintage and incomplete coverage. Do not describe archived market-cap buckets as today's measured market capitalizations.

The repository contains an MCP server implementation. Its files are bundled for reference only: this plugin does not register or host that server, supply credentials, or establish a live connection. If a user asks for that connection, inspect and configure the actual supported runtime separately.

