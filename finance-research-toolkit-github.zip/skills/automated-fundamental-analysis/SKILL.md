---
name: automated-fundamental-analysis
description: "Use the supplied Automated Fundamental Analysis Python project to inspect, adapt or run sector-relative stock grading and its Streamlit screening interface."
---

# Automated fundamental analysis

Read [upstream grading and usage](references/upstream.md). Inspect `assets/project/stockgrader.py`, `requirements.txt`, `WebApp/app.py` and `WebApp/utils.py` before execution.

The project scrapes Finviz and grades valuation, profitability, growth and price performance relative to sector distributions. The original dependencies and example data date from an older implementation; installing this skill does not establish current Finviz coverage or parser compatibility.

1. Clarify the universe, evaluation date, screening metrics and peer sectors.
2. Check an isolated Python environment against the pinned requirements. Review request behavior, selectors, supported fields, output filenames and import-time side effects before running `stockgrader.py`.
3. Test parsing on a small authorized sample before the documented full-universe run. Inspect missing values, percentage conversion, negative multiples, outliers and sector sizes.
4. Explain the actual score transformations and weighting from the code. Do not call heuristic letter grades credit ratings, predictive probabilities, or validated fair values.
5. Run `python stockgrader.py` only after establishing suitable inputs and provider access; record source dates and the number of successful/failed records.
6. For the UI, copy the project to a working directory and use `streamlit run app.py` from `WebApp/`, after checking what CSV paths the app expects.
7. Deliver a traceable table with component scores, total score, sector and missing-data flags. Interpret it as a shortlist for further research rather than a complete investment thesis.

For Indonesian stocks, do not assume the original Finviz universe covers IDX. Adapt the data layer to a verified source and label any changes to formulas or scoring. Report whether the screener was actually executed.

