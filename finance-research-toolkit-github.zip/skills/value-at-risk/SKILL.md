---
name: value-at-risk
description: "Use the supplied Databricks value-at-risk accelerator for portfolio Monte Carlo simulation, VaR aggregation, backtesting or Lakehouse risk-pipeline development."
---

# Value at risk

Read [the accelerator overview](references/upstream.md), then inspect `assets/project/config/application.yaml`, `assets/project/config/portfolio.json`, the numbered notebooks and `assets/project/utils/`.

This is a Databricks/Spark accelerator using Delta Lake, MLflow and tempo. It is not a standalone pandas script or a connected Databricks service. The README mentions both older and newer DBR versions; verify the actual target environment and dependencies before deployment.

- Clarify the portfolio positions, valuation currency/date, historical window, confidence level, holding period, return convention and treatment of missing data.
- Follow notebook dependency order: `00_var_context.py`, `01_var_market_etl.py`, `02_var_model.py`, `03_var_monte_carlo.py`, `04_var_aggregation.py`, `05_var_compliance.py`. Read the code before proposing individual cells.
- Replace demonstration dates and sample positions explicitly. The bundled YAML uses 2018-2020 data, 20 executors and 32,000 simulation runs; do not pass those off as current data or suitable default infrastructure.
- Scope table names and storage paths to the user's intended workspace. Describe cluster costs and table/model writes when those actions are relevant. Creating this skill does not authorize starting a paid cluster.
- Preserve cross-asset dependence in simulations and inspect seeds, fitted-model calibration, volatility windows and position valuation before aggregation.
- Present VaR as a positive loss threshold with currency, horizon and confidence stated. Distinguish VaR from Expected Shortfall; if adding ES, label that code as an extension.
- Check out-of-sample exceptions, model assumptions, concentration, liquidity and scenario stress. Do not interpret the example compliance notebook as evidence of regulatory approval.

When no Databricks session is connected, work with the source and prepare a scoped implementation. State which steps were actually run. A small local reproduction must be labeled as such and must not be represented as the original distributed accelerator.

