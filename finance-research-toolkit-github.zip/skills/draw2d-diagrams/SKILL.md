---
name: draw2d-diagrams
description: "Build editable browser-based diagrams, Visio-like flowcharts or workflow editors using the supplied Draw2D JavaScript library and source."
---

# Draw2D diagrams

Read [upstream overview](references/upstream.md). The supplied Draw2D 6.7.1 source is in `assets/project/src/`, with its distributable `assets/project/dist/draw2d.js`, `package.json` and license.

Use this skill when the user needs a Draw2D application, editable HTML diagram or diagram interaction. For a simple static explanatory diagram, use the host's native diagram support when it better fits the request.

- Establish the diagram's actors/swimlanes, nodes, decisions, edge directions, labels and export/editing needs.
- Inspect actual source APIs before implementation: search for `Canvas`, `Connection`, `createPort`, `CommandStack`, `io.json.Writer`, `io.json.Reader` and the relevant shape/router classes.
- Keep graph data distinct from layout. Use stable node/port IDs and explicit connection endpoints.
- Check the distributable's dependency expectations and the project's build configuration. The README's old Node version is historical guidance; use a verified compatible environment rather than assuming it is installed.
- Implement the smallest useful editor: canvas and required shapes/connections, with selection, dragging, undo/redo and JSON save/load only where requested.
- Handle JSON imports as data. Do not evaluate arbitrary JavaScript or permit untrusted class names to instantiate unrelated code.
- Validate port connections, cycles where prohibited by the domain, orthogonal routes, labels, zoom, scroll and overlap at the target viewport.
- Exercise a save/reload round trip and confirm graph IDs, node text and connection endpoints survive.
- Export to SVG/PNG only through supported APIs and verify the output. Draw2D is not a native VSDX writer; do not rename another format to .vsdx or claim Microsoft Visio compatibility without a valid converter.

Preserve upstream license notices when copying the library into an output project. Bundled source is a development resource, not a live hosted editor.

